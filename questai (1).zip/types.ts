
export interface User {
  id: string;
  username: string;
  email: string;
  passwordHash: string; // SHA-256 Hex
  mustChangePassword?: boolean;
  grade: string;
  isAdmin: boolean;
  stats: UserStats;
  learningProfile: LearningProfile;
  questHistory: CompletedQuest[];
  achievements: Achievement[];
  joinedDate: string;
}

export interface StudyDirective {
  id: string;
  task: string;
  duration: string;
  priority: 'CRITICAL' | 'STABLE' | 'OPTIMIZE';
  isCompleted: boolean;
}

export interface StudyPlan {
  directives: StudyDirective[];
  rationale: string;
  lastSynced: string;
}

export interface AccessKey {
  id: string;
  code: string;
  maxUses: number;
  currentUses: number;
  createdAt: string;
  isActive: boolean;
}

export interface GlobalConfig {
  xpMultiplier: number;
  maintenanceMode: boolean;
  systemBroadcast: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlockedAt: string;
}

export interface CompletedQuest {
  id: string;
  topic: string;
  difficulty: string;
  xpEarned: number;
  accuracy: number;
  completedAt: string;
  icon: string;
  pedagogyUsed: string;
}

export interface UserStats {
  level: number;
  xp: number;
  xpToNextLevel: number;
  questsCompleted: number;
  streak: number;
  rank: string;
  cognitiveLoad: number;
}

export interface LearningProfile {
  mistakes: MistakeRecord[];
  learningStyle: 'Balanced' | 'Repetitive' | 'Visual' | 'Fast-Track';
  struggleTopics: string[];
  successTopics: string[];
  averageAccuracy: number;
  totalAttempts: number;
  studyPlan?: StudyPlan;
}

export interface MistakeRecord {
  topic: string;
  question: string;
  userAnswer: string;
  correctAnswer: string;
  timestamp: string;
}

export interface QuestStep {
  id: string;
  title: string;
  content: string;
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
  xpReward: number;
}

export interface Quest {
  id: string;
  topic: string;
  difficulty: 'Novice' | 'Adept' | 'Master';
  description: string;
  steps: QuestStep[];
  totalXP: number;
  icon: string;
  pedagogyMode: string;
  synapticContext?: string;
}
