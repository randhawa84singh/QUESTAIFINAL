
import { User, Quest, MistakeRecord, CompletedQuest, AccessKey, GlobalConfig, StudyPlan } from "../types";
import { AI } from "./aiHandler";

/**
 * Server serves as the unified Sync Coordinator for the QuestAI platform.
 * It manages session persistence and routes intelligence requests to the AIHandler.
 */
class SyncCoordinator {
  private users: User[] = [];
  private keys: AccessKey[] = [];
  private config: GlobalConfig = { xpMultiplier: 1, maintenanceMode: false, systemBroadcast: "" };
  private currentUser: User | null = null;

  constructor() {
    this.users = JSON.parse(localStorage.getItem('quest_ai_users') || '[]');
    this.keys = JSON.parse(localStorage.getItem('quest_ai_keys') || '[]');
    this.config = JSON.parse(localStorage.getItem('quest_ai_config') || JSON.stringify(this.config));
    this.currentUser = JSON.parse(localStorage.getItem('quest_ai_session') || 'null');
    this.initAdmin();
  }

  private async hashPassword(password: string): Promise<string> {
    const msgUint8 = new TextEncoder().encode(password);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  private async initAdmin() {
    const adminEmail = 'admin@quest.ai';
    if (!this.users.find(u => u.email === adminEmail)) {
      const hash = await this.hashPassword("Qwerty");
      this.users.push({
        id: 'admin_001', username: 'HighCommand', email: adminEmail, passwordHash: hash,
        mustChangePassword: true, grade: 'Admin', isAdmin: true, joinedDate: new Date().toISOString(),
        stats: { level: 99, xp: 0, xpToNextLevel: 99999, questsCompleted: 1000, streak: 365, rank: 'Grandmaster', cognitiveLoad: 0 },
        learningProfile: { mistakes: [], learningStyle: 'Fast-Track', struggleTopics: [], successTopics: [], averageAccuracy: 100, totalAttempts: 0 },
        questHistory: [], achievements: []
      });
      this.save();
    }
  }

  private save() {
    localStorage.setItem('quest_ai_users', JSON.stringify(this.users));
    localStorage.setItem('quest_ai_keys', JSON.stringify(this.keys));
    localStorage.setItem('quest_ai_config', JSON.stringify(this.config));
    localStorage.setItem('quest_ai_session', JSON.stringify(this.currentUser));
  }

  // --- PERSISTENCE API ---
  
  async login(email: string, password?: string) {
    const user = this.users.find(u => u.email === email);
    if (!user) return { success: false, message: "Registry ID not found." };
    if (password) {
      const hash = await this.hashPassword(password);
      if (user.passwordHash !== hash) return { success: false, message: "Credential mismatch." };
    }
    this.currentUser = user;
    this.save();
    return { success: true, user };
  }

  async register(username: string, email: string, grade: string, keyCode: string, password: string) {
    const key = this.keys.find(k => k.code === keyCode && k.isActive && k.currentUses < k.maxUses);
    if (!key && keyCode !== 'GODMODE_DEBUG') return { success: false, message: "Deployment key invalid." };
    if (this.users.find(u => u.email === email)) return { success: false, message: "ID already in registry." };
    
    if (key) {
      key.currentUses++;
      if (key.currentUses >= key.maxUses) key.isActive = false;
    }
    const hash = await this.hashPassword(password);
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9), username, email, grade, isAdmin: false,
      passwordHash: hash, joinedDate: new Date().toISOString(),
      stats: { level: 1, xp: 0, xpToNextLevel: 1000, questsCompleted: 0, streak: 1, rank: 'Novice', cognitiveLoad: 0 },
      learningProfile: { mistakes: [], learningStyle: 'Balanced', struggleTopics: [], successTopics: [], averageAccuracy: 0, totalAttempts: 0 },
      questHistory: [], achievements: []
    };
    this.users.push(newUser);
    this.currentUser = newUser;
    this.save();
    return { success: true, user: newUser };
  }

  async changePassword(newPassword: string) {
    if (!this.currentUser) return false;
    this.currentUser.passwordHash = await this.hashPassword(newPassword);
    this.currentUser.mustChangePassword = false;
    this.users = this.users.map(u => u.id === this.currentUser?.id ? this.currentUser! : u);
    this.save();
    return true;
  }

  // --- INTELLIGENCE LAYER ---
  async createQuest(topic: string, difficulty: string, imageBase64?: string): Promise<Quest> {
    return await AI.generateQuest(topic, difficulty, this.currentUser?.grade || "10", this.currentUser?.learningProfile, imageBase64);
  }

  async getStudyPlan(): Promise<StudyPlan> {
    if (!this.currentUser) throw new Error("Authentication required.");
    return await AI.generateStudyPlan(this.currentUser);
  }

  async getFeedback(prompt: string): Promise<string> {
    return await AI.getFeedback(prompt);
  }

  async getSageVoice(text: string): Promise<AudioBuffer | null> {
    return await AI.synthesizeVoice(text);
  }

  // --- ANALYTICS TRACKING ---
  async completeQuest(quest: Quest, xpGained: number, accuracy: number) {
    if (!this.currentUser) return;
    const stats = this.currentUser.stats;
    const profile = this.currentUser.learningProfile;
    this.currentUser.questHistory.unshift({
      id: Math.random().toString(36).substr(2, 9), topic: quest.topic, difficulty: quest.difficulty,
      xpEarned: xpGained * this.config.xpMultiplier, accuracy, completedAt: new Date().toISOString(),
      icon: quest.icon, pedagogyUsed: quest.pedagogyMode
    });
    stats.xp += xpGained;
    profile.totalAttempts++;
    profile.averageAccuracy = ((profile.averageAccuracy * (profile.totalAttempts - 1)) + accuracy) / profile.totalAttempts;
    if (stats.xp >= stats.xpToNextLevel) { stats.level++; stats.xp -= stats.xpToNextLevel; stats.xpToNextLevel += 500; }
    this.save();
    return this.currentUser;
  }

  async logMistake(mistake: Omit<MistakeRecord, 'timestamp'>) {
    if (!this.currentUser) return;
    this.currentUser.learningProfile.mistakes.push({ ...mistake, timestamp: new Date().toISOString() });
    this.save();
  }

  generateKey(uses: number): AccessKey {
    const key = { id: Math.random().toString(36).substr(2, 9), code: `Q-${Math.random().toString(36).substr(2, 6).toUpperCase()}`, maxUses: uses, currentUses: 0, createdAt: new Date().toISOString(), isActive: true };
    this.keys.push(key);
    this.save();
    return key;
  }

  logout() { this.currentUser = null; this.save(); }
  getCurrentUser() { return this.currentUser; }
  getAllUsers() { return this.users; }
  getAllKeys() { return this.keys; }
  deleteKey(id: string) { this.keys = this.keys.filter(k => k.id !== id); this.save(); }
  async resetLearningProfile(userId: string) { const user = this.users.find(u => u.id === userId); if (user) { user.learningProfile = { mistakes: [], learningStyle: 'Balanced', struggleTopics: [], successTopics: [], averageAccuracy: 0, totalAttempts: 0 }; this.save(); } }
  async boostXP(userId: string, amount: number) { const user = this.users.find(u => u.id === userId); if (user) { user.stats.xp += amount; this.save(); } }
  async deleteUser(userId: string) { this.users = this.users.filter(u => u.id !== userId); this.save(); }
}

export const Server = new SyncCoordinator();
