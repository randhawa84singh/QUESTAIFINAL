
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { Quest, LearningProfile, StudyPlan, User } from "../types";

/**
 * Optimizes the curriculum quest generation by using a compressed 
 * prompt format and strictly enforced QCAA standards.
 */
export const generateQuest = async (topic: string, difficulty: string, grade: string, profile?: LearningProfile, imageBase64?: string): Promise<Quest> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const profileContext = profile ? 
    `Profile: ${profile.learningStyle}, Acc: ${Math.round(profile.averageAccuracy)}%, Struggles: ${profile.struggleTopics.slice(0, 2).join(',')}` : 
    'New Profile';

  const textPart = {
    text: `System: Sage (QCAA Neuro-Coordinator).
    Subject: Year ${grade} ${topic}.
    Difficulty: ${difficulty}.
    ${profileContext}.
    Task: Build a 3-step QCAA quest. If image provided, analyze it as source material (notes/homework). 
    Pedagogy: Adapt to profile style. Return JSON.`
  };

  const parts: any[] = [textPart];
  if (imageBase64) {
    parts.push({
      inlineData: {
        data: imageBase64.split(',')[1] || imageBase64,
        mimeType: 'image/jpeg'
      }
    });
  }

  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: { parts },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          topic: { type: Type.STRING },
          difficulty: { type: Type.STRING },
          description: { type: Type.STRING },
          icon: { type: Type.STRING },
          pedagogyMode: { type: Type.STRING },
          synapticContext: { type: Type.STRING },
          steps: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                title: { type: Type.STRING },
                content: { type: Type.STRING },
                question: { type: Type.STRING },
                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                correctAnswer: { type: Type.STRING },
                explanation: { type: Type.STRING },
                xpReward: { type: Type.NUMBER }
              },
              required: ["title", "content", "question", "options", "correctAnswer", "explanation", "xpReward"]
            }
          }
        },
        required: ["topic", "difficulty", "description", "steps"]
      }
    }
  });

  const data = JSON.parse(response.text || '{}');
  return {
    ...data,
    id: data.id || Math.random().toString(36).substr(2, 9),
    icon: data.icon || 'fa-brain',
    pedagogyMode: data.pedagogyMode || 'Standard',
    totalXP: data.steps ? data.steps.reduce((acc: number, s: any) => acc + s.xpReward, 0) : 0
  };
};

/**
 * Generates an AI-curated study plan based on user struggles and grade level.
 */
export const generateStudyPlan = async (user: User): Promise<StudyPlan> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze User Profile: Grade ${user.grade}, Accuracy ${user.learningProfile.averageAccuracy}%, Struggles: ${user.learningProfile.struggleTopics.join(', ')}. 
    Generate 3-4 daily study directives following QCAA standards. Return JSON.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          rationale: { type: Type.STRING, description: "Why these tasks were chosen based on struggles." },
          directives: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                task: { type: Type.STRING },
                duration: { type: Type.STRING },
                priority: { type: Type.STRING, enum: ['CRITICAL', 'STABLE', 'OPTIMIZE'] }
              },
              required: ["id", "task", "duration", "priority"]
            }
          }
        },
        required: ["rationale", "directives"]
      }
    }
  });

  const data = JSON.parse(response.text || '{}');
  return {
    ...data,
    lastSynced: new Date().toISOString(),
    directives: (data.directives || []).map((d: any) => ({ ...d, isCompleted: false }))
  };
};

/**
 * Provides pedagogical feedback and logic hints for student mistakes.
 */
export const getAIFeedback = async (history: any[], prompt: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      systemInstruction: "You are Sage, an AI mentor for Queensland students (QCAA). Provide concise, encouraging logic hints for mistakes without giving the direct answer.",
    },
  });
  return response.text || "Linking to Sage... please review your logic locally.";
};

/**
 * Text-to-Speech synthesis for the AI Mentor using Gemini TTS.
 */
export const synthesizeSageVoice = async (text: string): Promise<AudioBuffer | null> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: `Speak warmly and encouragingly as Sage the AI mentor: ${text}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) return null;

    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    return await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
  } catch (e) {
    console.error("TTS failed", e);
    return null;
  }
};

// Internal Audio Utilities
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
