
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { Quest, LearningProfile, StudyPlan, User } from "../types";

class AIHandler {
  private getClient() {
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async generateQuest(topic: string, difficulty: string, grade: string, profile?: LearningProfile, imageBase64?: string): Promise<Quest> {
    const ai = this.getClient();
    const profileContext = profile ? 
      `Profile: ${profile.learningStyle}, Acc: ${Math.round(profile.averageAccuracy)}%, Struggles: ${profile.struggleTopics.slice(0, 2).join(',')}` : 
      'New Profile';

    const parts: any[] = [{
      text: `System: Sage (QCAA Neuro-Coordinator).
      Subject: Year ${grade} ${topic}.
      Difficulty: ${difficulty}.
      Profile: ${profileContext}.
      
      CRITICAL INSTRUCTION: All scientific formulas, constants, and math MUST be in LaTeX format using single '$' for inline and '$$' for blocks. Use standard Markdown for bolding and structure.
      Example: '$c_{\text{ice}} = 2100 \text{ J kg}^{-1}\text{K}^{-1}$'.
      
      Task: Build a 3-step QCAA quest. Return JSON only.`
    }];

    if (imageBase64) {
      parts.push({
        inlineData: {
          data: imageBase64.split(',')[1] || imageBase64,
          mimeType: 'image/jpeg'
        }
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: { parts },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            topic: { type: Type.STRING },
            difficulty: { type: Type.STRING },
            description: { type: Type.STRING },
            icon: { type: Type.STRING },
            pedagogyMode: { type: Type.STRING },
            steps: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  title: { type: Type.STRING },
                  content: { type: Type.STRING, description: "Detailed explanation including LaTeX formulas." },
                  question: { type: Type.STRING, description: "Question text including LaTeX if needed." },
                  options: { type: Type.ARRAY, items: { type: Type.STRING } },
                  correctAnswer: { type: Type.STRING },
                  explanation: { type: Type.STRING, description: "Post-answer feedback with LaTeX." },
                  xpReward: { type: Type.NUMBER }
                }
              }
            }
          }
        }
      }
    });

    const data = JSON.parse(response.text || '{}');
    return {
      ...data,
      id: data.id || Math.random().toString(36).substr(2, 9),
      icon: data.icon || 'fa-brain',
      pedagogyMode: data.pedagogyMode || 'Standard',
      totalXP: data.steps?.reduce((acc: number, s: any) => acc + (s.xpReward || 0), 0) || 0
    };
  }

  async generateStudyPlan(user: User): Promise<StudyPlan> {
    const ai = this.getClient();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Profile: Grade ${user.grade}, Accuracy ${user.learningProfile.averageAccuracy}%, Struggles: ${user.learningProfile.struggleTopics.join(', ')}. Generate QCAA goals in JSON. Use LaTeX for any subject-specific terminology.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            rationale: { type: Type.STRING },
            directives: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  task: { type: Type.STRING },
                  duration: { type: Type.STRING },
                  priority: { type: Type.STRING }
                }
              }
            }
          }
        }
      }
    });

    const data = JSON.parse(response.text || '{}');
    return {
      ...data,
      lastSynced: new Date().toISOString(),
      directives: (data.directives || []).map((d: any) => ({ ...d, isCompleted: false }))
    };
  }

  async getFeedback(prompt: string): Promise<string> {
    const ai = this.getClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: "You are Sage, a QCAA AI mentor. Provide logic hints. ALWAYS use LaTeX for math/science content for clarity.",
      },
    });
    return response.text || "Connection lost to Sage archives.";
  }

  async synthesizeVoice(text: string): Promise<AudioBuffer | null> {
    try {
      const ai = this.getClient();
      // Clean LaTeX for TTS
      const cleanText = text.replace(/\$/g, '').replace(/\\text\{([^}]+)\}/g, '$1');
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Speak warmly as Sage: ${cleanText}` }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (!base64Audio) return null;

      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const audioData = this.decodeBase64(base64Audio);
      return await this.decodeAudio(audioData, ctx);
    } catch (e) {
      return null;
    }
  }

  private decodeBase64(base64: string) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  private async decodeAudio(data: Uint8Array, ctx: AudioContext): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const buffer = ctx.createBuffer(1, dataInt16.length, 24000);
    const channelData = buffer.getChannelData(0);
    for (let i = 0; i < dataInt16.length; i++) channelData[i] = dataInt16[i] / 32768.0;
    return buffer;
  }
}

export const AI = new AIHandler();
