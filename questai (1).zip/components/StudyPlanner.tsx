
import React, { useState } from 'react';
import { User, StudyPlan } from '../types';
import { Server } from '../services/server';

interface StudyPlannerProps {
  user: User;
  onPlanUpdate: (plan: StudyPlan) => void;
}

const StudyPlanner: React.FC<StudyPlannerProps> = ({ user, onPlanUpdate }) => {
  const [isSyncing, setIsSyncing] = useState(false);
  const plan = user.learningProfile.studyPlan;

  const handleSync = async () => {
    setIsSyncing(true);
    try {
      const newPlan = await Server.getStudyPlan();
      onPlanUpdate(newPlan);
    } catch (error) {
      console.error("Failed to sync neural planner.");
    } finally {
      setIsSyncing(false);
    }
  };

  const toggleTask = (id: string) => {
    if (!plan) return;
    const updatedPlan = {
      ...plan,
      directives: plan.directives.map(d => d.id === id ? { ...d, isCompleted: !d.isCompleted } : d)
    };
    onPlanUpdate(updatedPlan);
  };

  return (
    <div className="bg-slate-900/40 border border-slate-800/60 rounded-[3rem] p-8 relative overflow-hidden group shadow-2xl backdrop-blur-3xl">
      <div className="absolute top-0 right-0 p-8 opacity-5">
        <i className="fas fa-calendar-check text-8xl"></i>
      </div>

      <div className="flex items-center justify-between mb-8 relative z-10">
        <div>
          <h2 className="text-2xl font-orbitron font-black text-white tracking-tight uppercase">Neural Planner</h2>
          <p className="text-[10px] text-indigo-400 font-black uppercase tracking-[0.4em] mt-1">AI-Curated Directives</p>
        </div>
        <button 
          onClick={handleSync}
          disabled={isSyncing}
          className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${
            isSyncing ? 'bg-indigo-600 animate-spin' : 'bg-slate-800 hover:bg-indigo-600 text-slate-400 hover:text-white'
          }`}
          title="Sync with Sage AI"
        >
          <i className="fas fa-sync-alt"></i>
        </button>
      </div>

      {!plan ? (
        <div className="text-center py-12 space-y-4">
           <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fas fa-brain text-slate-600 text-2xl"></i>
           </div>
           <p className="text-xs font-black text-slate-500 uppercase tracking-widest">No Active Itinerary</p>
           <button 
             onClick={handleSync}
             className="text-[10px] font-black text-indigo-400 uppercase tracking-widest hover:underline"
           >
             Initialize Neural Sync
           </button>
        </div>
      ) : (
        <div className="space-y-6 relative z-10">
           <div className="bg-slate-950/40 border border-slate-800 rounded-2xl p-4">
              <p className="text-[9px] font-black text-indigo-500 uppercase tracking-widest mb-2 flex items-center">
                <i className="fas fa-robot mr-2"></i> Sage Rationale
              </p>
              <p className="text-xs text-slate-400 leading-relaxed italic">
                "{plan.rationale}"
              </p>
           </div>

           <div className="space-y-3">
              {plan.directives.map(task => (
                <div 
                  key={task.id} 
                  onClick={() => toggleTask(task.id)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center space-x-4 group/item ${
                    task.isCompleted 
                      ? 'bg-emerald-500/5 border-emerald-500/20' 
                      : 'bg-slate-950/40 border-slate-800 hover:border-indigo-500/30'
                  }`}
                >
                  <div className={`w-6 h-6 rounded-lg flex items-center justify-center transition-colors ${
                    task.isCompleted ? 'bg-emerald-500 text-white' : 'bg-slate-800 text-transparent group-hover/item:text-slate-600'
                  }`}>
                    <i className="fas fa-check text-[10px]"></i>
                  </div>
                  <div className="flex-1">
                    <p className={`text-xs font-bold transition-all ${task.isCompleted ? 'text-slate-500 line-through' : 'text-slate-200'}`}>
                      {task.task}
                    </p>
                    <div className="flex items-center space-x-3 mt-1">
                       <span className={`text-[8px] font-black uppercase tracking-widest ${
                         task.priority === 'CRITICAL' ? 'text-red-400' : 
                         task.priority === 'OPTIMIZE' ? 'text-indigo-400' : 'text-slate-500'
                       }`}>
                         {task.priority}
                       </span>
                       <span className="text-[8px] text-slate-600">•</span>
                       <span className="text-[8px] font-black text-slate-600 uppercase tracking-widest">{task.duration}</span>
                    </div>
                  </div>
                </div>
              ))}
           </div>
        </div>
      )}
    </div>
  );
};

export default StudyPlanner;
