
import React, { useState } from 'react';
import { Server } from '../services/server';
import { User } from '../types';

interface AuthProps {
  onAuthSuccess: (user: User) => void;
}

const Auth: React.FC<AuthProps> = ({ onAuthSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [grade, setGrade] = useState('10');
  const [keyCode, setKeyCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = isLogin 
        ? await Server.login(email, password)
        : await Server.register(username, email, grade, keyCode, password);

      if (response.success && response.user) {
        onAuthSuccess(response.user);
      } else {
        setError(response.message);
      }
    } catch (err) {
      setError("Communication failed. Base link offline.");
    } finally {
      setLoading(false);
    }
  };

  const grades = ['Prep', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];

  return (
    <div className="fixed inset-0 flex items-center justify-center p-4 bg-slate-950 overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1614850523459-c2f4c699c52e?auto=format&fit=crop&q=80')] bg-cover opacity-20 pointer-events-none"></div>
      <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 via-slate-950/80 to-indigo-950/40"></div>
      
      {/* Floating Blobs */}
      <div className="absolute top-1/4 -left-20 w-80 h-80 bg-indigo-600/20 rounded-full blur-[120px] animate-pulse"></div>
      <div className="absolute bottom-1/4 -right-20 w-80 h-80 bg-purple-600/20 rounded-full blur-[120px] animate-pulse delay-1000"></div>

      <div className="relative w-full max-w-md bg-slate-900/40 border border-slate-800/60 rounded-[3rem] shadow-2xl backdrop-blur-3xl p-8 md:p-12 animate-in fade-in zoom-in-95 duration-500">
        <div className="text-center mb-10">
          <div className="relative w-32 h-32 mx-auto mb-8">
            <div className="absolute inset-0 bg-indigo-600 rounded-full blur-2xl opacity-20 animate-pulse"></div>
            <div className="relative w-full h-full bg-slate-900 rounded-full border-4 border-indigo-500/50 p-2 flex items-center justify-center group overflow-hidden shadow-2xl">
              <img 
                src="https://raw.githubusercontent.com/google/material-design-icons/master/symbols/web/smart_toy/materialsymbolsoutlined24px.svg" 
                className="w-16 h-16 invert opacity-80 group-hover:scale-110 transition-transform" 
                alt="QuestAI Robot" 
              />
              <div className="absolute bottom-0 left-0 right-0 bg-indigo-600/20 backdrop-blur-sm py-1">
                 <p className="text-[8px] font-black text-indigo-100 tracking-tighter uppercase">Quest_Agent_01</p>
              </div>
            </div>
            <div className="absolute -top-2 -right-2 bg-slate-950 p-1.5 rounded-lg border border-indigo-500/50 rotate-12">
               <i className="fas fa-graduation-cap text-indigo-400 text-lg"></i>
            </div>
          </div>

          <h1 className="text-4xl font-orbitron font-black tracking-tighter bg-gradient-to-r from-white via-indigo-200 to-indigo-400 bg-clip-text text-transparent">
            QUEST AI
          </h1>
          <div className="flex items-center justify-center space-x-2 mt-4">
             <span className="h-px w-8 bg-slate-800"></span>
             <p className="text-indigo-400/60 text-[10px] uppercase tracking-[0.5em] font-black">Learn Smarter. Play Harder.</p>
             <span className="h-px w-8 bg-slate-800"></span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] text-indigo-400 font-black uppercase tracking-widest ml-1">Codename</label>
                <input 
                  type="text" required placeholder="STUDENT_X"
                  className="w-full bg-slate-800/30 border border-slate-700/50 rounded-2xl py-3 px-4 focus:border-indigo-500 outline-none transition-all text-sm font-bold"
                  value={username} onChange={(e) => setUsername(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] text-indigo-400 font-black uppercase tracking-widest ml-1">Year Level</label>
                <select 
                  className="w-full bg-slate-800/30 border border-slate-700/50 rounded-2xl py-3 px-4 focus:border-indigo-500 outline-none transition-all text-sm font-bold appearance-none text-slate-400"
                  value={grade} onChange={(e) => setGrade(e.target.value)}
                >
                  {grades.map(g => <option key={g} value={g} className="bg-slate-900">Year {g}</option>)}
                </select>
              </div>
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-[10px] text-indigo-400 font-black uppercase tracking-widest ml-1">Registry ID (Email)</label>
            <input 
              type="email" required placeholder="user@quest.ai"
              className="w-full bg-slate-800/30 border border-slate-700/50 rounded-2xl py-3 px-6 focus:border-indigo-500 outline-none transition-all text-sm font-bold"
              value={email} onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-[10px] text-indigo-400 font-black uppercase tracking-widest ml-1">Neural Key (Password)</label>
            <input 
              type="password" required placeholder="••••••••"
              className="w-full bg-slate-800/30 border border-slate-700/50 rounded-2xl py-3 px-6 focus:border-indigo-500 outline-none transition-all text-sm font-bold"
              value={password} onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          {!isLogin && (
            <div className="space-y-1.5">
              <label className="text-[10px] text-indigo-400 font-black uppercase tracking-widest ml-1">Deployment Access Key</label>
              <input 
                type="text" required placeholder="Q-XXXXXX"
                className="w-full bg-slate-800/30 border border-slate-700/50 rounded-2xl py-3 px-6 focus:border-indigo-500 outline-none transition-all text-sm font-bold placeholder:opacity-20 uppercase"
                value={keyCode} onChange={(e) => setKeyCode(e.target.value)}
              />
            </div>
          )}

          {error && <p className="text-red-400 text-[10px] text-center font-black bg-red-400/5 py-3 rounded-xl border border-red-400/20 uppercase tracking-widest">{error}</p>}

          <button 
            type="submit" disabled={loading}
            className="w-full mt-4 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 hover:to-indigo-400 text-white font-black py-4 rounded-2xl transition-all shadow-xl shadow-indigo-600/20 flex items-center justify-center space-x-3 group uppercase tracking-[0.2em] text-xs"
          >
            {loading ? <i className="fas fa-circle-notch animate-spin text-lg"></i> : (
              <>
                <span>{isLogin ? 'Initiate Link' : 'Register Profile'}</span>
                <i className="fas fa-bolt group-hover:scale-125 transition-transform"></i>
              </>
            )}
          </button>
        </form>

        <div className="mt-8 text-center">
          <button 
            onClick={() => setIsLogin(!isLogin)}
            className="text-slate-500 hover:text-indigo-400 text-[11px] font-black uppercase tracking-widest transition-colors"
          >
            {isLogin ? "No archives? Create Profile" : "Existing Link? Sign In"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Auth;
