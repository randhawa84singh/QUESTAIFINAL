
import React, { useState } from 'react';
import { Server } from '../services/server';
import { User, AccessKey } from '../types';

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'registry' | 'vault' | 'system'>('registry');
  const [users, setUsers] = useState<User[]>(Server.getAllUsers());
  const [keys, setKeys] = useState<AccessKey[]>(Server.getAllKeys());
  const [keyUses, setKeyUses] = useState(30);

  const handleGenerateKey = () => {
    const newKey = Server.generateKey(keyUses);
    setKeys(Server.getAllKeys());
    alert(`NEW ACCESS KEY FORGED: ${newKey.code}\nCapacity: ${newKey.maxUses} users.`);
  };

  const handleResetProfile = async (id: string) => {
    if (confirm("Reset neural history for this student? This clears mistakes and resets learning style to Balanced.")) {
      await Server.resetLearningProfile(id);
      setUsers(Server.getAllUsers());
    }
  };

  const handleBoostXP = async (id: string) => {
    await Server.boostXP(id, 500);
    setUsers(Server.getAllUsers());
  };

  const handleDelete = async (id: string) => {
    if (confirm("Purge this user profile from the archive?")) {
      await Server.deleteUser(id);
      setUsers(Server.getAllUsers());
    }
  };

  const globalAccuracy = users.length > 0 
    ? Math.round(users.reduce((acc, u) => acc + u.learningProfile.averageAccuracy, 0) / users.length) 
    : 0;

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500 pb-20">
      {/* Header Panel */}
      <div className="bg-slate-900 border border-slate-800 p-8 rounded-[3rem] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-5">
          <i className="fas fa-user-shield text-9xl"></i>
        </div>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <h2 className="text-4xl font-orbitron font-black text-white tracking-tighter">HIGH COMMAND</h2>
            <p className="text-indigo-400 text-[10px] font-black uppercase tracking-[0.4em] mt-2">Operational System Control</p>
          </div>
          <div className="flex gap-4">
            <div className="bg-slate-950 p-4 px-8 rounded-3xl border border-slate-800 text-center">
               <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Global Health</p>
               <p className="text-2xl font-orbitron font-black text-emerald-400">{globalAccuracy}% SYNC</p>
            </div>
            <div className="bg-slate-950 p-4 px-8 rounded-3xl border border-slate-800 text-center">
               <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Active Agents</p>
               <p className="text-2xl font-orbitron font-black text-indigo-400">{users.length}</p>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-2 mt-10">
          {[
            { id: 'registry', label: 'Agent Registry', icon: 'fa-users' },
            { id: 'vault', label: 'Key Vault', icon: 'fa-key' },
            { id: 'system', label: 'System Commands', icon: 'fa-cogs' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-3 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${
                activeTab === tab.id 
                ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-600/20' 
                : 'bg-slate-800/50 text-slate-400 hover:bg-slate-800'
              }`}
            >
              <i className={`fas ${tab.icon}`}></i>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <div className="bg-slate-900/40 border border-slate-800/60 rounded-[3rem] overflow-hidden backdrop-blur-3xl min-h-[500px]">
        {activeTab === 'registry' && (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="bg-slate-800/50 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                <th className="px-8 py-5">Agent Identity</th>
                <th className="px-6 py-5">DNA Status</th>
                <th className="px-6 py-5">Accuracy</th>
                <th className="px-6 py-5">Commands</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {users.map(user => (
                <tr key={user.id} className="hover:bg-slate-800/20 transition-colors">
                  <td className="px-8 py-5">
                    <div className="flex items-center space-x-4">
                      <img src={`https://api.dicebear.com/7.x/bottts/svg?seed=${user.username}`} className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700" />
                      <div>
                        <p className="font-black text-white">{user.username}</p>
                        <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Year {user.grade}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <span className={`text-[9px] font-black px-3 py-1 rounded-full ${
                      user.learningProfile.learningStyle === 'Fast-Track' ? 'bg-emerald-500/10 text-emerald-400' :
                      user.learningProfile.learningStyle === 'Repetitive' ? 'bg-orange-500/10 text-orange-400' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {user.learningProfile.learningStyle.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex items-center space-x-3">
                       <div className="w-16 h-1 bg-slate-800 rounded-full overflow-hidden">
                          <div className="h-full bg-indigo-500" style={{ width: `${user.learningProfile.averageAccuracy}%` }}></div>
                       </div>
                       <span className="text-xs font-bold text-white">{Math.round(user.learningProfile.averageAccuracy)}%</span>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <div className="flex space-x-3">
                       {!user.isAdmin && (
                         <>
                           <button onClick={() => handleBoostXP(user.id)} className="p-2 bg-indigo-500/10 text-indigo-400 hover:bg-indigo-500/20 rounded-lg transition-colors" title="Boost XP">
                             <i className="fas fa-bolt"></i>
                           </button>
                           <button onClick={() => handleResetProfile(user.id)} className="p-2 bg-orange-500/10 text-orange-400 hover:bg-orange-500/20 rounded-lg transition-colors" title="Reset Neural History">
                             <i className="fas fa-undo"></i>
                           </button>
                           <button onClick={() => handleDelete(user.id)} className="p-2 bg-red-500/10 text-red-500 hover:bg-red-500/20 rounded-lg transition-colors" title="Delete Account">
                             <i className="fas fa-trash"></i>
                           </button>
                         </>
                       )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {activeTab === 'vault' && (
          <div className="p-10 space-y-10">
            <div className="flex flex-col md:flex-row items-end gap-6 bg-slate-950/40 p-8 rounded-[2.5rem] border border-slate-800">
               <div className="flex-1 space-y-3">
                  <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Key Usage Capacity (Students)</label>
                  <input 
                    type="number" 
                    className="w-full bg-slate-900 border border-slate-700 rounded-2xl py-4 px-6 text-white font-bold outline-none focus:border-indigo-500 transition-all"
                    value={keyUses} onChange={(e) => setKeyUses(parseInt(e.target.value))}
                  />
               </div>
               <button 
                 onClick={handleGenerateKey}
                 className="bg-indigo-600 hover:bg-indigo-500 text-white font-black py-4 px-10 rounded-2xl transition-all uppercase tracking-widest text-xs shadow-xl shadow-indigo-600/20"
               >
                 FORGE ACCESS KEY
               </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {keys.map(key => (
                <div key={key.id} className={`p-6 rounded-[2rem] border-2 transition-all ${
                  key.isActive ? 'bg-slate-900/40 border-slate-800' : 'bg-slate-900/10 border-slate-800 opacity-40 grayscale'
                }`}>
                   <div className="flex justify-between items-start mb-6">
                      <div className="bg-indigo-500/10 p-3 rounded-xl">
                        <i className="fas fa-shield-alt text-indigo-400 text-xl"></i>
                      </div>
                      <span className={`text-[8px] font-black px-2 py-1 rounded uppercase ${key.isActive ? 'bg-emerald-500/20 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}>
                        {key.isActive ? 'Active' : 'Expired'}
                      </span>
                   </div>
                   <p className="text-xl font-orbitron font-black text-white mb-2">{key.code}</p>
                   <div className="space-y-3">
                      <div className="flex justify-between text-[10px] font-black uppercase text-slate-500">
                         <span>Payload</span>
                         <span>{key.currentUses} / {key.maxUses} Agents</span>
                      </div>
                      <div className="h-1.5 bg-slate-950 rounded-full overflow-hidden">
                        <div className="h-full bg-indigo-500" style={{ width: `${(key.currentUses / key.maxUses) * 100}%` }}></div>
                      </div>
                   </div>
                   <button 
                     onClick={() => { Server.deleteKey(key.id); setKeys(Server.getAllKeys()); }}
                     className="w-full mt-6 py-3 border border-red-500/20 text-red-500 hover:bg-red-500/10 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all"
                   >
                     RECALL KEY
                   </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'system' && (
          <div className="p-10">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <div className="bg-slate-950/40 border border-slate-800 p-8 rounded-[2.5rem] space-y-6">
                  <h4 className="text-white font-orbitron font-black text-sm uppercase">Global Overrides</h4>
                  <div className="space-y-4">
                     <button className="w-full flex justify-between items-center p-5 bg-slate-900 border border-slate-800 rounded-2xl hover:border-indigo-500 transition-all group">
                        <span className="text-xs font-bold text-slate-400 group-hover:text-white uppercase tracking-widest">Double XP Protocol</span>
                        <div className="w-10 h-5 bg-slate-950 rounded-full relative p-1">
                           <div className="w-3 h-3 bg-slate-700 rounded-full"></div>
                        </div>
                     </button>
                     <button className="w-full flex justify-between items-center p-5 bg-slate-900 border border-slate-800 rounded-2xl hover:border-red-500 transition-all group">
                        <span className="text-xs font-bold text-slate-400 group-hover:text-white uppercase tracking-widest">System Lockout</span>
                        <div className="w-10 h-5 bg-slate-950 rounded-full relative p-1">
                           <div className="w-3 h-3 bg-slate-700 rounded-full"></div>
                        </div>
                     </button>
                  </div>
               </div>
               
               <div className="bg-indigo-600/5 border border-indigo-500/10 p-8 rounded-[2.5rem] space-y-6">
                  <h4 className="text-white font-orbitron font-black text-sm uppercase">System Pulse</h4>
                  <div className="space-y-3">
                     <div className="flex justify-between items-center p-4 bg-slate-950/40 rounded-xl">
                        <span className="text-[10px] font-black text-slate-500 uppercase">Latency</span>
                        <span className="text-[10px] font-black text-emerald-400">14ms - OPTIMAL</span>
                     </div>
                     <div className="flex justify-between items-center p-4 bg-slate-950/40 rounded-xl">
                        <span className="text-[10px] font-black text-slate-500 uppercase">Registry Status</span>
                        <span className="text-[10px] font-black text-indigo-400">HEALTHY</span>
                     </div>
                     <div className="flex justify-between items-center p-4 bg-slate-950/40 rounded-xl">
                        <span className="text-[10px] font-black text-slate-500 uppercase">AI Load</span>
                        <span className="text-[10px] font-black text-slate-200">12.4%</span>
                     </div>
                  </div>
               </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
