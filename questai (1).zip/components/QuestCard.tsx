
import React from 'react';
import { Quest } from '../types';

interface QuestCardProps {
  quest: Partial<Quest>;
  onStart: () => void;
  isCustom?: boolean;
}

const QuestCard: React.FC<QuestCardProps> = ({ quest, onStart, isCustom }) => {
  return (
    <div className="quest-card-gradient border border-slate-800 rounded-2xl p-6 hover:border-indigo-500 transition-all group relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full -mr-16 -mt-16 blur-2xl group-hover:bg-indigo-500/20 transition-colors"></div>
      
      <div className="flex items-start justify-between mb-4 relative z-10">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${isCustom ? 'bg-purple-600' : 'bg-slate-700'}`}>
          <i className={`fas ${quest.icon || 'fa-scroll'} text-white text-xl`}></i>
        </div>
        <span className={`text-xs font-bold px-2 py-1 rounded uppercase tracking-wider ${
          quest.difficulty === 'Master' ? 'bg-red-500/20 text-red-400' : 
          quest.difficulty === 'Adept' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-green-500/20 text-green-400'
        }`}>
          {quest.difficulty}
        </span>
      </div>

      <h3 className="text-xl font-orbitron font-bold mb-2 group-hover:text-indigo-400 transition-colors">
        {quest.topic}
      </h3>
      <p className="text-slate-400 text-sm mb-6 line-clamp-2">
        {quest.description || "Master the fundamentals of this topic with AI-guided challenges."}
      </p>

      <div className="flex items-center justify-between mt-auto pt-4 border-t border-slate-800/50">
        <div className="flex items-center space-x-1 text-xs text-slate-500 font-bold">
          <i className="fas fa-bolt text-indigo-400"></i>
          <span>{quest.totalXP || '???'} XP</span>
        </div>
        <button 
          onClick={onStart}
          className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold py-2 px-4 rounded-lg transition-colors flex items-center space-x-2"
        >
          <span>START QUEST</span>
          <i className="fas fa-chevron-right text-[10px]"></i>
        </button>
      </div>
    </div>
  );
};

export default QuestCard;
