
import React, { useState, useEffect, useRef } from 'react';
import { Quest } from '../types';
import { Server } from '../services/server';
import RichText from './RichText';

interface QuestPlayerProps {
  quest: Quest;
  onComplete: (earnedXP: number, accuracy: number) => void;
  onExit: () => void;
}

const QuestPlayer: React.FC<QuestPlayerProps> = ({ quest, onComplete, onExit }) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [totalEarnedXP, setTotalEarnedXP] = useState(0);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [aiMessage, setAiMessage] = useState<string>(`Sage Protocol Active: Adaptive pedagogy mode "${quest.pedagogyMode}" is now controlling mission difficulty.`);
  const [isThinking, setIsThinking] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);

  const currentStep = quest.steps[currentStepIndex];

  useEffect(() => {
    speakFeedback(aiMessage);
  }, []);

  const speakFeedback = async (text: string) => {
    const buffer = await Server.getSageVoice(text);
    if (buffer) {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const source = audioContextRef.current.createBufferSource();
      source.buffer = buffer;
      source.connect(audioContextRef.current.destination);
      source.start();
    }
  };

  const handleOptionSelect = (option: string) => {
    if (isAnswered) return;
    setSelectedOption(option);
  };

  const checkAnswer = async () => {
    if (!selectedOption) return;
    
    const correct = selectedOption === currentStep.correctAnswer;
    setIsCorrect(correct);
    setIsAnswered(true);

    if (correct) {
      setTotalEarnedXP(prev => prev + currentStep.xpReward);
      setCorrectAnswers(prev => prev + 1);
      const msg = `Positive sync: ${currentStep.explanation}`;
      setAiMessage(msg);
      speakFeedback(msg);
    } else {
      setIsThinking(true);
      await Server.logMistake({
        topic: quest.topic,
        question: currentStep.question,
        userAnswer: selectedOption,
        correctAnswer: currentStep.correctAnswer
      });
      
      const feedback = await Server.getFeedback(`Context: QCAA Year ${quest.topic}. Mistake on: ${currentStep.question}. User picked: ${selectedOption}. Logic hint needed with LaTeX.`);
      setAiMessage(feedback);
      speakFeedback(feedback);
      setIsThinking(false);
    }
  };

  const nextStep = () => {
    if (currentStepIndex < quest.steps.length - 1) {
      setCurrentStepIndex(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      const accuracy = (correctAnswers / quest.steps.length) * 100;
      onComplete(totalEarnedXP, accuracy);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20 animate-in fade-in duration-500">
      <div className="flex items-center justify-between bg-slate-900/60 border border-indigo-500/20 p-5 rounded-3xl backdrop-blur-xl">
        <div className="flex items-center space-x-6">
          <button onClick={onExit} className="text-slate-500 hover:text-red-400 transition-colors">
            <i className="fas fa-times-circle text-2xl"></i>
          </button>
          <div className="h-10 w-px bg-slate-800"></div>
          <div>
            <p className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.4em] leading-none mb-1">Mission Target</p>
            <h2 className="text-lg font-orbitron font-black text-white leading-none uppercase truncate max-w-[200px]">{quest.topic}</h2>
          </div>
        </div>

        <div className="flex items-center space-x-10">
          <div className="hidden md:block">
            <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest text-right mb-1">Synaptic Sync</p>
            <div className="w-48 h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
               <div className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all duration-1000" style={{ width: `${((currentStepIndex + 1) / quest.steps.length) * 100}%` }}></div>
            </div>
          </div>
          <div className="text-center">
            <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Data Gain</p>
            <p className="text-sm font-orbitron font-black text-indigo-400">+{totalEarnedXP} XP</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-[3rem] p-8 md:p-14 relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-indigo-500 to-transparent opacity-30"></div>
            
            <div className="relative mb-12">
               <span className="text-[10px] font-black text-indigo-400 bg-indigo-500/10 px-3 py-1.5 rounded-full border border-indigo-500/20 uppercase tracking-[0.3em] mb-4 inline-block">
                 Sequence {currentStepIndex + 1} of {quest.steps.length}
               </span>
               <h3 className="text-3xl md:text-5xl font-orbitron font-black text-white leading-tight uppercase tracking-tighter">
                 {currentStep.title}
               </h3>
            </div>

            <div className="prose prose-invert max-w-none text-slate-400 text-lg md:text-xl leading-relaxed font-medium mb-12">
               <RichText content={currentStep.content} />
            </div>

            <div className="pt-10 border-t border-slate-800/50">
               <div className="text-xl md:text-2xl font-bold mb-10 text-indigo-50 text-center lg:text-left flex items-start">
                 <i className="fas fa-microchip text-indigo-500 mr-4 mt-2 opacity-50"></i>
                 <RichText content={currentStep.question} />
               </div>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 {currentStep.options.map((option, idx) => (
                   <button
                     key={idx}
                     disabled={isAnswered}
                     onClick={() => handleOptionSelect(option)}
                     className={`text-left p-6 rounded-2xl border-2 transition-all flex items-center justify-between group ${
                       selectedOption === option 
                         ? (isAnswered 
                             ? (isCorrect ? 'border-emerald-500 bg-emerald-500/10' : 'border-red-500 bg-red-500/10')
                             : 'border-indigo-500 bg-indigo-600/20 shadow-2xl') 
                         : 'border-slate-800 bg-slate-950/40 hover:border-slate-700'
                     }`}
                   >
                     <span className="font-bold text-sm md:text-base leading-tight">
                        <RichText content={option} />
                     </span>
                     {isAnswered && option === currentStep.correctAnswer && <i className="fas fa-check-circle text-emerald-500 animate-bounce"></i>}
                   </button>
                 ))}
               </div>
            </div>

            <div className="mt-12 flex justify-center lg:justify-end">
              {!isAnswered ? (
                <button
                  disabled={!selectedOption}
                  onClick={checkAnswer}
                  className="w-full lg:w-auto bg-indigo-600 hover:bg-indigo-500 disabled:opacity-20 text-white font-black py-5 px-16 rounded-[2rem] transition-all shadow-[0_15px_40px_rgba(79,70,229,0.3)] uppercase tracking-[0.3em] text-xs"
                >
                  Confirm Choice
                </button>
              ) : (
                <button
                  onClick={nextStep}
                  className="w-full lg:w-auto bg-emerald-600 hover:bg-emerald-500 text-white font-black py-5 px-16 rounded-[2rem] transition-all flex items-center justify-center space-x-4 uppercase tracking-[0.3em] text-xs"
                >
                  <span>{currentStepIndex < quest.steps.length - 1 ? 'Next Sequence' : 'Finalize Sync'}</span>
                  <i className="fas fa-chevron-right"></i>
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 space-y-6 sticky top-28">
          <div className="bg-slate-900 border border-slate-800 rounded-[2.5rem] p-8 relative overflow-hidden shadow-2xl">
            <div className="flex justify-center mb-8">
               <div className="relative w-24 h-24">
                  <div className="absolute inset-0 border-2 border-indigo-500/20 rounded-full"></div>
                  <div className="absolute inset-0 border-2 border-indigo-500 rounded-full border-t-transparent animate-spin"></div>
                  <div className="absolute inset-4 flex items-center justify-center">
                     <i className="fas fa-satellite-dish text-indigo-400 text-3xl animate-pulse"></i>
                  </div>
               </div>
            </div>

            <div className="text-center mb-8">
               <h4 className="font-orbitron font-black text-white tracking-widest text-xs uppercase">Mentor_SAGE</h4>
               <p className="text-[9px] font-black text-indigo-400 uppercase tracking-[0.5em] mt-2 opacity-50">Operational Intelligence</p>
            </div>

            <div className="bg-slate-950/50 border border-slate-800 rounded-2xl p-6 min-h-[160px] flex items-center justify-center text-center">
              {isThinking ? (
                <div className="space-y-4">
                  <div className="flex justify-center space-x-1">
                     <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                     <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                     <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce"></div>
                  </div>
                  <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Consulting QCAA Archive...</p>
                </div>
              ) : (
                <div className="text-xs md:text-sm text-slate-300 font-bold leading-relaxed italic">
                  <RichText content={aiMessage} />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuestPlayer;
