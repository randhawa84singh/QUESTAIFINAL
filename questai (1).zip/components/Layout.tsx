
import React from 'react';
import { User } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  user: User;
  onLogout: () => void;
  onHome: () => void;
}

const Layout: React.FC<LayoutProps> = ({ children, user, onLogout, onHome }) => {
  const stats = user.stats;
  const xpPercentage = (stats.xp / stats.xpToNextLevel) * 100;

  return (
    <div className="min-h-screen flex flex-col bg-[#010410] text-slate-100">
      {/* HUD Header */}
      <nav className="border-b border-slate-800/50 bg-slate-950/40 backdrop-blur-2xl sticky top-0 z-50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <button 
              onClick={onHome}
              className="group flex items-center space-x-3 hover:opacity-80 transition-opacity"
            >
              <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-[0_0_20px_rgba(79,70,229,0.3)] group-hover:scale-105 transition-transform">
                <i className="fas fa-home text-white text-lg"></i>
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-orbitron font-black tracking-tighter bg-gradient-to-r from-indigo-400 to-purple-500 bg-clip-text text-transparent leading-none">
                  QUEST AI
                </span>
                <span className="text-[8px] font-black text-slate-500 tracking-[0.2em] uppercase">Queensland Base</span>
              </div>
            </button>
          </div>

          <div className="flex-1 max-w-sm mx-12 hidden lg:block">
            <div className="flex justify-between text-[9px] font-black uppercase tracking-widest text-slate-500 mb-1.5">
              <span>SYNC_LVL: {stats.level}</span>
              <span>{user.grade !== 'Admin' ? `Year ${user.grade}` : 'CMD_SYS'}</span>
              <span>{Math.round(xpPercentage)}%_DATA</span>
            </div>
            <div className="h-1.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
               <div 
                 className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-500 transition-all duration-1000 bg-[length:200%_100%] animate-[gradient_3s_linear_infinite]" 
                 style={{ width: `${xpPercentage}%` }}
               ></div>
            </div>
          </div>

          <div className="flex items-center space-x-5">
            <div className="hidden sm:flex flex-col items-end mr-2">
              <span className="text-[9px] font-black text-indigo-400 uppercase tracking-widest">{user.username}</span>
              <span className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">Year {user.grade}</span>
            </div>
            
            <div className="relative group">
              <button className="w-11 h-11 rounded-2xl bg-slate-900 border border-slate-800 p-0.5 flex items-center justify-center overflow-hidden hover:border-indigo-500/50 transition-all shadow-inner">
                 <img src={`https://api.dicebear.com/7.x/bottts/svg?seed=${user.username}`} alt="Avatar" className="w-full h-full object-cover rounded-[14px]" />
              </button>
              
              <div className="absolute right-0 top-full mt-3 w-56 bg-slate-900 border border-slate-800 rounded-2xl shadow-[0_10px_40px_rgba(0,0,0,0.5)] opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all p-2 z-[60] backdrop-blur-3xl">
                <div className="px-4 py-3 border-b border-slate-800 mb-2">
                  <p className="text-xs font-black text-white truncate">{user.username}</p>
                  <p className="text-[10px] text-slate-500 font-bold truncate mt-0.5">{user.email}</p>
                </div>
                <button className="w-full text-left px-4 py-2.5 hover:bg-slate-800 rounded-xl text-xs font-bold flex items-center space-x-3 transition-colors text-slate-300">
                   <i className="fas fa-id-card text-indigo-400"></i>
                   <span>Operational Profile</span>
                </button>
                <button className="w-full text-left px-4 py-2.5 hover:bg-slate-800 rounded-xl text-xs font-bold flex items-center space-x-3 transition-colors text-slate-300">
                   <i className="fas fa-terminal text-indigo-400"></i>
                   <span>System Logs</span>
                </button>
                <div className="h-px bg-slate-800 my-2 mx-2"></div>
                <button 
                  onClick={onLogout}
                  className="w-full text-left px-4 py-2.5 hover:bg-red-500/10 text-red-500 rounded-xl text-xs font-bold flex items-center space-x-3 transition-colors"
                >
                   <i className="fas fa-power-off"></i>
                   <span>Sever Connection</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-6 py-8 relative">
        {children}
      </main>

      <footer className="border-t border-slate-900 bg-slate-950/20 py-10 px-6 text-center text-slate-600">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex flex-col items-center md:items-start">
            <p className="text-[10px] uppercase tracking-[0.3em] font-black text-slate-500">&copy; 2025 QuestAI Queensland</p>
            <p className="text-[9px] font-bold text-slate-700 mt-1 uppercase tracking-widest">Authorized for Educational Simulation Only</p>
          </div>
          <div className="flex items-center space-x-10 text-[10px] font-black uppercase tracking-[0.2em]">
            <a href="#" className="hover:text-indigo-400 transition-colors">QCAA Compliance</a>
            <a href="#" className="hover:text-indigo-400 transition-colors">Admin Portal</a>
            <a href="#" className="hover:text-indigo-400 transition-colors">Security</a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
