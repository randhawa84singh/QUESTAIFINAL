
import React, { useState, useRef } from 'react';
import Layout from './components/Layout';
import QuestCard from './components/QuestCard';
import QuestPlayer from './components/QuestPlayer';
import Auth from './components/Auth';
import AdminDashboard from './components/AdminDashboard';
import StudyPlanner from './components/StudyPlanner';
import { Server } from './services/server';
import { User, Quest, StudyPlan } from './types';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(Server.getCurrentUser());
  const [activeQuest, setActiveQuest] = useState<Quest | null>(null);
  const [loading, setLoading] = useState(false);
  const [customTopic, setCustomTopic] = useState('');
  const [showCompleteModal, setShowCompleteModal] = useState(false);
  const [lastEarnedXP, setLastEarnedXP] = useState(0);
  const [isAdminView, setIsAdminView] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!user) return <Auth onAuthSuccess={(u) => setUser(u)} />;

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const success = await Server.changePassword(newPassword);
    if (success) {
      setUser(Server.getCurrentUser());
    }
    setLoading(false);
  };

  const handleStartQuest = async (topic: string, difficulty: string = 'Novice', imageBase64?: string) => {
    setLoading(true);
    try {
      const quest = await Server.createQuest(topic, difficulty);
      setActiveQuest(quest);
      setIsAdminView(false);
    } catch (error) {
      alert("Synchronization failure. Link to Sage lost.");
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      await handleStartQuest("Analyzed Subject", "Adept", base64);
    };
    reader.readAsDataURL(file);
  };

  const handleQuestComplete = async (earnedXP: number, accuracy: number) => {
    if (!activeQuest) return;
    setLoading(true);
    try {
      const updatedUser = await Server.completeQuest(activeQuest, earnedXP, accuracy);
      if (updatedUser) setUser({ ...updatedUser });
      setLastEarnedXP(earnedXP);
      setShowCompleteModal(true);
      setActiveQuest(null);
    } catch (error) {
      console.error("Critical DB Sync failure.");
    } finally {
      setLoading(false);
    }
  };

  const updateStudyPlan = (newPlan: StudyPlan) => {
    if (!user) return;
    const updatedUser = {
      ...user,
      learningProfile: {
        ...user.learningProfile,
        studyPlan: newPlan
      }
    };
    setUser(updatedUser);
    // Persist user state locally
    const users = JSON.parse(localStorage.getItem('quest_ai_users') || '[]');
    const updatedUsers = users.map((u: User) => u.id === user.id ? updatedUser : u);
    localStorage.setItem('quest_ai_users', JSON.stringify(updatedUsers));
    localStorage.setItem('quest_ai_session', JSON.stringify(updatedUser));
  };

  const qcaaQuests: Partial<Quest>[] = [
    { id: 'q1', topic: 'Year 11 Physics: Unit 1', difficulty: 'Adept', description: 'Master Thermal, Nuclear and Electrical Physics for QCE Unit 1.', icon: 'fa-atom', totalXP: 450 },
    { id: 'q2', topic: 'Year 10 Maths Methods', difficulty: 'Novice', description: 'Algebraic expansion and factorisation fundamentals.', icon: 'fa-calculator', totalXP: 300 },
    { id: 'q3', topic: 'Year 12 Chemistry: Redox', difficulty: 'Master', description: 'Advanced electrochemical cells and oxidation numbers.', icon: 'fa-vial', totalXP: 600 },
  ];

  return (
    <Layout 
      user={user} 
      onLogout={() => { Server.logout(); setUser(null); }} 
      onHome={() => { setActiveQuest(null); setIsAdminView(false); }}
    >
      {/* Forced Password Rotation Modal */}
      {user.mustChangePassword && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center bg-slate-950/98 backdrop-blur-3xl p-4">
          <div className="bg-slate-900 border border-indigo-500/40 w-full max-w-md rounded-[3rem] p-10 space-y-8 animate-in zoom-in-95">
             <div className="text-center space-y-4">
                <div className="w-20 h-20 bg-indigo-500/10 rounded-full flex items-center justify-center mx-auto border border-indigo-500/20">
                   <i className="fas fa-key-skeleton text-3xl text-indigo-400"></i>
                </div>
                <h2 className="text-2xl font-orbitron font-black text-white uppercase tracking-tighter">RE-ENCRYPT LINK</h2>
                <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.4em]">Mandatory Security Rotation</p>
             </div>
             <form onSubmit={handlePasswordChange} className="space-y-6">
                <div className="space-y-2">
                   <label className="text-[9px] font-black text-indigo-400 uppercase tracking-widest ml-1">New Neural Key</label>
                   <input 
                     type="password" required placeholder="••••••••"
                     className="w-full bg-slate-950 border border-slate-800 rounded-2xl py-4 px-6 text-white font-bold outline-none focus:border-indigo-500"
                     value={newPassword} onChange={(e) => setNewPassword(e.target.value)}
                   />
                </div>
                <button type="submit" className="w-full bg-indigo-600 py-4 rounded-2xl font-black text-white uppercase tracking-widest text-xs hover:bg-indigo-500 shadow-xl shadow-indigo-600/20">
                   Update Credentials
                </button>
             </form>
          </div>
        </div>
      )}

      {activeQuest ? (
        <QuestPlayer quest={activeQuest} onComplete={handleQuestComplete} onExit={() => setActiveQuest(null)} />
      ) : isAdminView ? (
        <AdminDashboard />
      ) : (
        <div className="space-y-16 animate-in fade-in duration-1000">
          {/* Main Command Input Section */}
          <section className="relative overflow-hidden bg-slate-900 border border-slate-800 p-8 md:p-20 rounded-[4rem] shadow-2xl">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_20%,_var(--tw-gradient-stops))] from-indigo-500/10 via-transparent to-transparent opacity-50"></div>
            
            <div className="relative z-10 space-y-10 max-w-5xl">
              <div className="flex flex-wrap gap-4 mb-4">
                 {user.isAdmin && (
                   <button 
                     onClick={() => setIsAdminView(true)}
                     className="bg-amber-500/10 border border-amber-500/20 text-amber-500 px-6 py-2.5 rounded-2xl text-[11px] font-black uppercase tracking-widest hover:bg-amber-500/20 transition-all flex items-center space-x-3"
                   >
                     <i className="fas fa-user-shield"></i>
                     <span>Admin Command Center</span>
                   </button>
                 )}
                 <div className="flex items-center space-x-3 bg-slate-950/60 border border-slate-800 px-5 py-2.5 rounded-2xl text-[11px] font-black uppercase tracking-widest text-indigo-300">
                    <span className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse"></span>
                    <span>Link Mode: {user.learningProfile.learningStyle}</span>
                 </div>
              </div>

              <div className="space-y-4">
                <h1 className="text-5xl md:text-8xl font-orbitron font-black leading-none tracking-tighter text-white">
                  INITIATE <span className="bg-gradient-to-r from-indigo-500 to-purple-500 bg-clip-text text-transparent">SYNAPTIC</span> LINK
                </h1>
                <p className="text-slate-500 text-xl md:text-2xl leading-relaxed max-w-3xl font-medium">
                   Welcome back, Agent <span className="text-white">{user.username}</span>. Your Year {user.grade} QCAA mission profile is ready for neural deployment.
                </p>
              </div>
              
              <div className="flex flex-col lg:flex-row gap-6 pt-10">
                <div className="relative flex-1 group">
                  <div className="absolute left-6 top-1/2 -translate-y-1/2 flex items-center space-x-4">
                     <i className="fas fa-terminal text-slate-600 group-focus-within:text-indigo-500 transition-colors"></i>
                  </div>
                  <input 
                    type="text" placeholder="ENTER_MISSION_TOPIC..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-[2.5rem] py-8 px-16 focus:border-indigo-500 outline-none transition-all text-white font-black text-lg md:text-xl uppercase tracking-widest placeholder:text-slate-800 shadow-inner"
                    value={customTopic} onChange={(e) => setCustomTopic(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && customTopic && handleStartQuest(customTopic)}
                  />
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 flex space-x-2">
                     <button 
                       onClick={() => fileInputRef.current?.click()}
                       className="w-14 h-14 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500 hover:text-indigo-400 hover:border-indigo-500/50 transition-all"
                       title="Analyze Notes (Camera)"
                     >
                       <i className="fas fa-camera text-xl"></i>
                     </button>
                     <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileUpload} />
                  </div>
                </div>
                <button 
                  onClick={() => customTopic && handleStartQuest(customTopic)}
                  disabled={!customTopic || loading}
                  className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-black py-8 px-20 rounded-[2.5rem] shadow-[0_20px_60px_rgba(79,70,229,0.3)] transition-all uppercase tracking-[0.4em] text-sm group"
                >
                  <span>ENGAGE</span>
                  <i className="fas fa-bolt ml-4 group-hover:scale-125 transition-transform"></i>
                </button>
              </div>
            </div>
          </section>

          {/* Cognitive HUD Grid */}
          <section className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { label: 'Intelligence Level', val: user.stats.level, icon: 'fa-brain', color: 'indigo' },
              { label: 'Neural Sync Rate', val: `${Math.round(user.learningProfile.averageAccuracy)}%`, icon: 'fa-wave-square', color: 'emerald' },
              { label: 'Registry Errors', val: user.learningProfile.mistakes.length, icon: 'fa-bug', color: 'red' },
              { label: 'Active Streak', val: `${user.stats.streak} Days`, icon: 'fa-fire-alt', color: 'orange' },
            ].map((stat, i) => (
              <div key={i} className="bg-slate-900/40 border border-slate-800/60 p-8 rounded-[2.5rem] hover:border-slate-700 transition-all group hover:bg-slate-900/60">
                <div className={`w-14 h-14 rounded-2xl bg-${stat.color}-500/10 flex items-center justify-center text-${stat.color}-400 mb-6 group-hover:scale-110 transition-transform`}>
                  <i className={`fas ${stat.icon} text-2xl`}></i>
                </div>
                <p className="text-[10px] text-slate-600 font-black uppercase tracking-widest">{stat.label}</p>
                <p className="text-2xl font-orbitron font-black text-white mt-2 uppercase truncate">{stat.val}</p>
              </div>
            ))}
          </section>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
            {/* Mission Catalog */}
            <div className="lg:col-span-8 space-y-10">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-3xl font-orbitron font-black tracking-tight text-white">MISSION PROTOCOLS</h2>
                  <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.4em] mt-2">Curated for Queensland Year {user.grade}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {qcaaQuests.map((quest) => (
                  <QuestCard 
                    key={quest.id} 
                    quest={quest} 
                    onStart={() => handleStartQuest(quest.topic!, quest.difficulty!)} 
                  />
                ))}
              </div>

              {/* Neural Planner Integration */}
              <div className="pt-8">
                <StudyPlanner user={user} onPlanUpdate={updateStudyPlan} />
              </div>
            </div>

            {/* Neuro History Log */}
            <div className="lg:col-span-4 space-y-10">
              <div className="flex items-center justify-between">
                 <h2 className="text-2xl font-orbitron font-black tracking-tight uppercase text-white">Neural Logs</h2>
                 <span className="text-[9px] font-black text-indigo-400 bg-indigo-500/10 px-2 py-1 rounded">Archive_OK</span>
              </div>

              <div className="space-y-4 max-h-[800px] overflow-y-auto pr-2 custom-scrollbar">
                {user.questHistory && user.questHistory.length > 0 ? (
                  user.questHistory.map((history) => (
                    <div key={history.id} className="bg-slate-900/60 border border-slate-800 p-5 rounded-3xl flex items-center space-x-4 group hover:border-indigo-500/40 transition-all">
                      <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 group-hover:rotate-12 transition-transform shadow-inner">
                        <i className={`fas ${history.icon || 'fa-database'} text-lg`}></i>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-black text-white truncate uppercase tracking-tighter">{history.topic}</p>
                        <div className="flex items-center space-x-2 text-[10px] text-slate-500 font-black uppercase tracking-[0.2em] mt-1">
                          <span className={history.difficulty === 'Master' ? 'text-red-500' : 'text-emerald-500'}>{history.difficulty}</span>
                          <span>•</span>
                          <span>{history.accuracy}% Acc</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-orbitron font-black text-indigo-500">+{history.xpEarned}</p>
                        <p className="text-[8px] font-black text-slate-700 uppercase">SYN_DATA</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-20 border border-slate-800 border-dashed rounded-[3rem] bg-slate-900/20">
                    <i className="fas fa-ghost text-slate-800 text-5xl mb-6"></i>
                    <p className="text-[10px] font-black text-slate-700 uppercase tracking-[0.5em]">No Logged Synapses</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Persistence Success Layer */}
      {showCompleteModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-3xl">
          <div className="bg-slate-900 border border-indigo-500/40 w-full max-w-xl rounded-[4rem] p-16 text-center space-y-10 shadow-2xl animate-in zoom-in-95 duration-500">
            <div className="w-32 h-32 bg-gradient-to-br from-indigo-600 to-purple-700 rounded-[2.5rem] flex items-center justify-center text-white mx-auto shadow-[0_0_60px_rgba(79,70,229,0.4)] rotate-6">
               <i className="fas fa-award text-6xl"></i>
            </div>
            
            <div className="space-y-4">
              <h2 className="text-5xl font-orbitron font-black text-white uppercase tracking-tighter">DATA SYNC COMPLETE</h2>
              <p className="text-slate-500 font-black uppercase tracking-[0.4em] text-[10px]">Cognitive Profile Stabilized</p>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="bg-slate-950 border border-slate-800 p-8 rounded-[2.5rem]">
                <p className="text-[10px] text-slate-600 font-black uppercase tracking-widest mb-2">Sync Earned</p>
                <p className="text-4xl font-orbitron font-black text-indigo-400">+{lastEarnedXP}</p>
              </div>
              <div className="bg-slate-950 border border-slate-800 p-8 rounded-[2.5rem]">
                <p className="text-[10px] text-slate-600 font-black uppercase tracking-widest mb-2">Network Level</p>
                <p className="text-4xl font-orbitron font-black text-purple-400">{user.stats.level}</p>
              </div>
            </div>

            <button 
              onClick={() => setShowCompleteModal(false)} 
              className="w-full bg-indigo-600 py-6 rounded-3xl font-black text-white uppercase tracking-[0.5em] text-sm hover:bg-indigo-500 transition-all shadow-xl shadow-indigo-600/20"
            >
              Return to Command Base
            </button>
          </div>
        </div>
      )}

      {/* Neural Link Overlay */}
      {loading && (
        <div className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-slate-950/98 backdrop-blur-2xl">
          <div className="relative w-64 h-64 mb-12">
            <div className="absolute inset-0 border-[6px] border-indigo-500/10 rounded-full"></div>
            <div className="absolute inset-0 border-[6px] border-indigo-500 rounded-full border-t-transparent animate-[spin_1s_linear_infinite]"></div>
            <div className="absolute inset-10 border-[6px] border-purple-500/20 rounded-full animate-pulse"></div>
            <div className="absolute inset-10 border-[6px] border-purple-500 rounded-full border-b-transparent animate-[spin_2s_linear_infinite_reverse]"></div>
            <div className="absolute inset-0 flex items-center justify-center">
               <i className="fas fa-brain text-indigo-400 text-5xl animate-bounce"></i>
            </div>
          </div>
          <div className="text-center space-y-6">
            <p className="text-3xl font-orbitron font-black text-white tracking-[0.5em] uppercase animate-pulse">Establishing Neuro-Link</p>
            <p className="text-slate-600 font-black text-[11px] uppercase tracking-[0.6em]">Consulting Sage Intelligence Archives...</p>
          </div>
        </div>
      )}
    </Layout>
  );
};

export default App;
